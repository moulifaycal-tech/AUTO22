import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

// ─── CONFIG ─────────────────────────────────────────────
const AGENCY_NUMBER = "212660499714";
const AGENCY_NAME = "AUTO22";
const TODAY = "2026-06-02";
const MONTH_YEAR = { year: 2026, month: 5 }; // 0-indexed June

// ─── HELPERS ────────────────────────────────────────────
const DOC_LABELS = { permis: "Permis de conduire", passeport: "Passeport", caution: "Caution / Dépôt" };
const STATUTS = {
  confirmee: { label: "Confirmée",  color: "#22c55e", bg: "#052e16" },
  attente:   { label: "En attente", color: "#f59e0b", bg: "#1c1003" },
  en_cours:  { label: "En cours",   color: "#3b82f6", bg: "#0c1a3a" },
  terminee:  { label: "Terminée",   color: "#6b7280", bg: "#161616" },
  annulee:   { label: "Annulée",    color: "#ef4444", bg: "#1a0505" },
};
const getMissing = d => Object.entries(d).filter(([,v])=>!v).map(([k])=>DOC_LABELS[k]);
const daysBetween = (a,b) => Math.ceil((new Date(b)-new Date(a))/86400000);
const buildWAUrl = (res, agencyNum=AGENCY_NUMBER) => {
  const msg = `Bonjour Auto22 🚗\nRéservation : ${res.id}\nNom : ${res.client}\nVéhicule : ${res.vehicule}\n\nDocuments à envoyer :\n${getMissing(res.docs).length===0?"✅ Dossier complet":getMissing(res.docs).map(d=>`❌ ${d}`).join("\n")}\n\nMerci d'envoyer la photo de chaque document.`;
  return `https://wa.me/${agencyNum}?text=${encodeURIComponent(msg)}`;
};
const buildReminderUrl = res => {
  const msg = `Bonjour ${res.client} 👋\n\nRappel Auto22 🚗\nVotre ${res.vehicule} vous sera livré demain ${res.debut} à ${res.livraison.heure}.\n📍 Lieu : ${res.livraison.lieu}\n\n${getMissing(res.docs).length>0?`⚠️ Documents manquants :\n${getMissing(res.docs).map(d=>`• ${d}`).join("\n")}\nMerci de les envoyer dès que possible.`:"✅ Votre dossier est complet."}\n\nÀ demain ! 🙏\nAuto22`;
  return `https://wa.me/${res.phone.replace(/\D/g,"")}?text=${encodeURIComponent(msg)}`;
};
const buildQRUrl = (url,size=150) => `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&color=000000&bgcolor=ffffff&data=${encodeURIComponent(url)}&qzone=1`;

// ─── INITIAL DATA ────────────────────────────────────────
const INIT_FLEET = [
  { id:"V-01", nom:"Dacia Duster 2023",    immat:"12345-A-6", cat:"SUV",      prix:400,  statut:"loue",        km:45000, couleur:"#e85d04" },
  { id:"V-02", nom:"Hyundai Tucson 2024",  immat:"67890-B-7", cat:"SUV",      prix:600,  statut:"loue",        km:12000, couleur:"#3b82f6" },
  { id:"V-03", nom:"Peugeot 3008 2023",    immat:"11223-C-5", cat:"SUV",      prix:600,  statut:"loue",        km:28000, couleur:"#8b5cf6" },
  { id:"V-04", nom:"Renault Clio 2024",    immat:"44556-D-3", cat:"Citadine", prix:300,  statut:"loue",        km:8000,  couleur:"#22c55e" },
  { id:"V-05", nom:"Kia Sportage 2024",    immat:"78901-E-2", cat:"SUV",      prix:700,  statut:"loue",        km:5000,  couleur:"#f59e0b" },
  { id:"V-06", nom:"Toyota Yaris 2023",    immat:"33221-F-1", cat:"Citadine", prix:280,  statut:"libre",       km:32000, couleur:"#06b6d4" },
  { id:"V-07", nom:"Volkswagen Polo 2024", immat:"55443-G-9", cat:"Citadine", prix:320,  statut:"maintenance", km:61000, couleur:"#ec4899" },
];

const INIT_RES = [
  {id:"R-001",client:"Karim Benali",   phone:"+212 6 12 34 56 78",vehicule:"Dacia Duster 2023",   immat:"12345-A-6",debut:"2026-06-02",fin:"2026-06-07",statut:"confirmee",livraison:{heure:"09:00",lieu:"Aéroport CMN"},retour:{heure:"18:00",lieu:"Agence"},docs:{permis:true, passeport:false,caution:true}, montant:2400},
  {id:"R-002",client:"Sara El Fassi",  phone:"+212 6 98 76 54 32",vehicule:"Hyundai Tucson 2024", immat:"67890-B-7",debut:"2026-06-02",fin:"2026-06-05",statut:"attente",  livraison:{heure:"11:30",lieu:"Hôtel Sofitel"},retour:{heure:"10:00",lieu:"Hôtel Sofitel"},docs:{permis:false,passeport:false,caution:false},montant:1800},
  {id:"R-003",client:"Youssef Amrani", phone:"+212 6 55 44 33 22",vehicule:"Peugeot 3008 2023",   immat:"11223-C-5",debut:"2026-06-03",fin:"2026-06-10",statut:"confirmee",livraison:{heure:"14:00",lieu:"Agence"},retour:{heure:"14:00",lieu:"Agence"},docs:{permis:true, passeport:true, caution:true}, montant:4200},
  {id:"R-004",client:"Nadia Chraibi",  phone:"+212 6 77 88 99 00",vehicule:"Renault Clio 2024",   immat:"44556-D-3",debut:"2026-06-04",fin:"2026-06-06",statut:"en_cours",  livraison:{heure:"08:00",lieu:"Gare Casa Voyageurs"},retour:{heure:"20:00",lieu:"Agence"},docs:{permis:true, passeport:true, caution:false},montant:900},
  {id:"R-005",client:"Omar Kettani",   phone:"+212 6 11 22 33 44",vehicule:"Kia Sportage 2024",   immat:"78901-E-2",debut:"2026-06-05",fin:"2026-06-12",statut:"attente",  livraison:{heure:"10:00",lieu:"Aéroport CMN"},retour:{heure:"09:00",lieu:"Aéroport CMN"},docs:{permis:true, passeport:false,caution:false},montant:4900},
  {id:"R-006",client:"Fatima Zahra",   phone:"+212 6 33 44 55 66",vehicule:"Toyota Yaris 2023",   immat:"33221-F-1",debut:"2026-06-08",fin:"2026-06-11",statut:"confirmee",livraison:{heure:"10:00",lieu:"Agence"},retour:{heure:"10:00",lieu:"Agence"},docs:{permis:false,passeport:false,caution:false},montant:840},
  {id:"R-007",client:"Hassan Mbarki",  phone:"+212 6 22 11 33 44",vehicule:"Dacia Duster 2023",   immat:"12345-A-6",debut:"2026-06-10",fin:"2026-06-15",statut:"attente",  livraison:{heure:"09:00",lieu:"Agence"},retour:{heure:"09:00",lieu:"Agence"},docs:{permis:true, passeport:false,caution:false},montant:2000},
];

const STATS_HISTORY = [
  {mois:"Jan",ca:18400,res:12},{mois:"Fév",ca:21000,res:14},{mois:"Mar",ca:28500,res:18},
  {mois:"Avr",ca:32000,res:21},{mois:"Mai",ca:27800,res:17},{mois:"Juin",ca:17200,res:7},
];

// ─── PDF CONTRACT ────────────────────────────────────────
function generateContract(res) {
  const jours = daysBetween(res.debut, res.fin);
  const prixJour = Math.round(res.montant / jours);
  const st = STATUTS[res.statut];
  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Contrat ${res.id}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Helvetica Neue',Arial,sans-serif;color:#111;padding:40px;font-size:13px;line-height:1.5}
  .hdr{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:20px;border-bottom:3px solid #e85d04;margin-bottom:24px}
  .logo{font-size:32px;font-weight:900;color:#e85d04;letter-spacing:-1px}.logo span{color:#111}
  .title{font-size:18px;font-weight:700;text-align:center;margin:20px 0 24px;text-transform:uppercase;letter-spacing:1px;color:#e85d04}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px}
  .box{border:1px solid #ddd;border-radius:8px;padding:14px}
  .box-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#888;margin-bottom:8px}
  .box-val{font-size:14px;font-weight:700}
  .box-sub{font-size:12px;color:#666;margin-top:2px}
  table{width:100%;border-collapse:collapse;margin:16px 0}
  th{background:#f3f4f6;padding:9px 12px;text-align:left;font-size:11px;font-weight:700;text-transform:uppercase;border:1px solid #e5e7eb}
  td{padding:9px 12px;border:1px solid #e5e7eb;font-size:13px}
  .total-row{background:#fff7ed;font-weight:700;color:#e85d04}
  .conditions{background:#f9f9f9;border-radius:8px;padding:14px;margin:16px 0;font-size:11px;color:#555;line-height:1.8}
  .sig-grid{display:grid;grid-template-columns:1fr 1fr;gap:30px;margin-top:30px}
  .sig-box{border-top:2px solid #ddd;padding-top:12px}
  .sig-label{font-size:11px;color:#888;font-weight:600}
  .sig-name{font-size:13px;font-weight:700;margin-top:4px}
  .sig-area{height:60px;border:1px dashed #ddd;border-radius:6px;margin-top:8px;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:11px}
  .footer{margin-top:24px;padding-top:12px;border-top:1px solid #eee;display:flex;justify-content:space-between;font-size:10px;color:#aaa}
  .badge{display:inline-block;padding:3px 10px;border-radius:4px;font-size:11px;font-weight:700;background:#fff7ed;color:#e85d04;border:1px solid #fed7aa}
  @media print{body{padding:20px}}
</style></head><body>
<div class="hdr">
  <div><div class="logo">AUTO<span>22</span></div><div style="font-size:11px;color:#888;margin-top:3px">Agence de Location de Véhicules</div><div style="font-size:11px;color:#888">+${AGENCY_NUMBER} · Maroc</div></div>
  <div style="text-align:right"><div class="badge">CONTRAT ${res.id}</div><div style="font-size:11px;color:#888;margin-top:6px">Émis le ${new Date().toLocaleDateString("fr-FR")}</div><div style="font-size:12px;font-weight:700;color:${st.color};margin-top:4px">${st.label}</div></div>
</div>

<div class="title">Contrat de Location de Véhicule</div>

<div class="grid2">
  <div class="box"><div class="box-title">👤 Locataire</div><div class="box-val">${res.client}</div><div class="box-sub">${res.phone}</div></div>
  <div class="box"><div class="box-title">🚗 Véhicule loué</div><div class="box-val">${res.vehicule}</div><div class="box-sub">Immatriculation : ${res.immat}</div></div>
  <div class="box"><div class="box-title">🚀 Prise en charge</div><div class="box-val">${res.debut} à ${res.livraison.heure}</div><div class="box-sub">📍 ${res.livraison.lieu}</div></div>
  <div class="box"><div class="box-title">🔁 Restitution</div><div class="box-val">${res.fin} à ${res.retour.heure}</div><div class="box-sub">📍 ${res.retour.lieu}</div></div>
</div>

<div class="box-title" style="margin-bottom:8px">💰 Détail financier</div>
<table>
  <tr><th>Désignation</th><th>Détail</th><th style="text-align:right">Montant</th></tr>
  <tr><td>Location véhicule</td><td>${jours} jour${jours>1?"s":""} × ${prixJour.toLocaleString("fr-FR")} DH/jour</td><td style="text-align:right">${res.montant.toLocaleString("fr-FR")} DH</td></tr>
  <tr><td>Caution / Dépôt de garantie</td><td>Remboursable à la restitution</td><td style="text-align:right">2 000 DH</td></tr>
  <tr class="total-row"><td colspan="2"><strong>TOTAL À RÉGLER</strong></td><td style="text-align:right"><strong>${res.montant.toLocaleString("fr-FR")} DH</strong></td></tr>
</table>

<div class="box-title" style="margin-bottom:8px">📄 Documents reçus</div>
<table>
  <tr><th>Document</th><th>Statut</th></tr>
  ${["permis","passeport","caution"].map(k=>`<tr><td>${DOC_LABELS[k]}</td><td style="color:${res.docs[k]?"#16a34a":"#dc2626"};font-weight:700">${res.docs[k]?"✅ Reçu":"❌ Manquant"}</td></tr>`).join("")}
</table>

<div class="conditions">
  <strong style="color:#111;font-size:12px">Conditions générales de location :</strong><br>
  1. Le véhicule doit être restitué dans l'état initial, propre et avec le même niveau de carburant.<br>
  2. Tout dommage constaté sera à la charge du locataire selon le barème en vigueur.<br>
  3. La caution sera restituée dans les 48h suivant la restitution du véhicule en bon état.<br>
  4. Le locataire s'engage à respecter le Code de la Route et les lois marocaines.<br>
  5. En cas de panne ou d'accident, contacter immédiatement l'agence au +${AGENCY_NUMBER}.<br>
  6. Le conducteur doit être titulaire d'un permis valide depuis au moins 2 ans.
</div>

<div class="sig-grid">
  <div class="sig-box">
    <div class="sig-label">Signature du locataire</div>
    <div class="sig-name">${res.client}</div>
    <div class="sig-area">Signature + date</div>
  </div>
  <div class="sig-box">
    <div class="sig-label">Signature Auto22</div>
    <div class="sig-name">L'Agence</div>
    <div class="sig-area">Cachet + signature</div>
  </div>
</div>

<div class="footer"><div>AUTO22 · +${AGENCY_NUMBER} · Maroc</div><div>Contrat ${res.id} · ${res.client} · ${new Date().toLocaleDateString("fr-FR")}</div></div>
<script>window.print();</script>
</body></html>`;
  const w = window.open("","_blank"); w.document.write(html); w.document.close();
}

// ─── PDF DOSSIER ─────────────────────────────────────────
function exportDossier(res) {
  const jours = daysBetween(res.debut, res.fin);
  const st = STATUTS[res.statut];
  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Dossier ${res.id}</title>
<style>body{font-family:'Helvetica Neue',Arial,sans-serif;padding:40px;color:#111;font-size:13px}.hdr{display:flex;justify-content:space-between;padding-bottom:16px;border-bottom:3px solid #e85d04;margin-bottom:20px}.logo{font-size:28px;font-weight:900;color:#e85d04}.logo span{color:#111}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin:14px 0}.card{background:#f9f9f9;border-radius:8px;padding:12px;border:1px solid #eee}.card-t{font-size:10px;font-weight:700;color:#888;text-transform:uppercase;margin-bottom:6px}.docs{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:14px 0}.doc{text-align:center;padding:14px;border-radius:8px;border:2px solid}.doc.ok{background:#f0fdf4;border-color:#22c55e;color:#166534}.doc.nok{background:#fef2f2;border-color:#ef4444;color:#dc2626}.footer{margin-top:24px;padding-top:12px;border-top:1px solid #eee;font-size:10px;color:#aaa;display:flex;justify-content:space-between}@media print{body{padding:20px}}</style></head><body>
<div class="hdr"><div><div class="logo">AUTO<span>22</span></div><div style="font-size:11px;color:#888">Location de véhicules</div></div><div style="text-align:right"><div style="background:#e85d04;color:#fff;padding:4px 12px;border-radius:5px;font-size:12px;font-weight:700">${res.id}</div><div style="font-size:11px;color:#888;margin-top:4px">${new Date().toLocaleDateString("fr-FR")}</div><div style="font-size:12px;font-weight:700;color:${st.color};margin-top:4px">${st.label}</div></div></div>
<div class="grid"><div class="card"><div class="card-t">Client</div><div style="font-weight:700;font-size:15px">${res.client}</div><div style="color:#666;font-size:12px">${res.phone}</div></div><div class="card"><div class="card-t">Véhicule</div><div style="font-weight:700;font-size:15px">${res.vehicule}</div><div style="color:#666;font-size:12px">${res.immat}</div></div><div class="card"><div class="card-t">Livraison</div><div style="font-weight:700">${res.debut} à ${res.livraison.heure}</div><div style="color:#666;font-size:12px">📍 ${res.livraison.lieu}</div></div><div class="card"><div class="card-t">Retour</div><div style="font-weight:700">${res.fin} à ${res.retour.heure}</div><div style="color:#666;font-size:12px">📍 ${res.retour.lieu} · ${jours}j</div></div></div>
<div style="font-size:22px;font-weight:900;color:#e85d04">${res.montant.toLocaleString("fr-FR")} DH</div>
<div class="docs">${["permis","passeport","caution"].map(k=>`<div class="doc ${res.docs[k]?"ok":"nok"}"><div style="font-size:22px;margin-bottom:4px">${res.docs[k]?"✅":"❌"}</div><div style="font-size:11px;font-weight:700">${DOC_LABELS[k]}</div><div style="font-size:10px;margin-top:2px">${res.docs[k]?"Reçu":"Manquant"}</div></div>`).join("")}</div>
<div class="footer"><div>AUTO22 · +${AGENCY_NUMBER}</div><div>Dossier ${res.id} · ${res.client}</div></div>
<script>window.print();</script></body></html>`;
  const w = window.open("","_blank"); w.document.write(html); w.document.close();
}

// ─── CLAUDE API ──────────────────────────────────────────
async function detectDoc(message, reservations) {
  const resList = reservations.map(r=>({id:r.id,client:r.client,missing:getMissing(r.docs)}));
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:400,system:`Assistant Auto22. Identifie réservation+document(s) depuis message WhatsApp. JSON UNIQUEMENT: {"reservationId":"R-001","clientName":"...","documents":["passeport"],"confidence":"high","message":"..."}. Documents: permis, passeport, caution. Impossible: {"confidence":"low","reservationId":null,"documents":[],"message":"..."}`,messages:[{role:"user",content:`Réservations:\n${JSON.stringify(resList)}\n\nMessage: "${message}"`}]})});
    const data = await res.json();
    return JSON.parse((data.content?.[0]?.text||"{}").replace(/```json|```/g,"").trim());
  } catch { return {confidence:"low",reservationId:null,documents:[],message:"Erreur réseau"}; }
}

// ─── NOTIFICATIONS ───────────────────────────────────────
function buildNotifs(reservations) {
  const n = [];
  reservations.forEach(r => {
    const miss = getMissing(r.docs); const dStart = daysBetween(TODAY,r.debut); const dEnd = daysBetween(TODAY,r.fin);
    if (miss.length>0 && dStart<=1 && !["annulee","terminee"].includes(r.statut)) n.push({id:`u-${r.id}`,type:"urgent",icon:"🚨",title:`Dossier incomplet — ${r.id}`,body:`${r.client} : ${miss.join(", ")}`,sub:`Livraison ${dStart===0?"aujourd'hui":"demain"} à ${r.livraison.heure}`,resId:r.id});
    else if (miss.length>0 && !["annulee","terminee"].includes(r.statut)) n.push({id:`w-${r.id}`,type:"warning",icon:"⚠️",title:`Docs manquants — ${r.id}`,body:`${r.client} : ${miss.join(", ")}`,sub:`Livraison dans ${dStart}j`,resId:r.id});
    if (r.debut===TODAY && r.statut==="confirmee") n.push({id:`l-${r.id}`,type:"info",icon:"🚀",title:`Livraison aujourd'hui — ${r.id}`,body:`${r.client} · ${r.vehicule}`,sub:`${r.livraison.heure} · ${r.livraison.lieu}`,resId:r.id});
    if (r.fin===TODAY && r.statut==="en_cours") n.push({id:`r-${r.id}`,type:"info",icon:"🔁",title:`Retour aujourd'hui — ${r.id}`,body:`${r.client} · ${r.vehicule}`,sub:`${r.retour.heure} · ${r.retour.lieu}`,resId:r.id});
  });
  return n;
}

// ─── FORM ────────────────────────────────────────────────
function ReservationForm({ reservations, fleet, onSave, onClose }) {
  const nextId = `R-${String(reservations.length+1).padStart(3,"0")}`;
  const [form, setForm] = useState({client:"",phone:"",vehiculeId:"",debut:"",fin:"",statut:"attente",lheure:"09:00",llieu:"Agence",rheure:"18:00",rlieu:"Agence",montant:""});
  const [errors, setErrors] = useState({});

  const set = (k,v) => {
    const upd = {...form,[k]:v};
    if ((k==="vehiculeId"||k==="debut"||k==="fin") && upd.vehiculeId && upd.debut && upd.fin && upd.fin>upd.debut) {
      const veh = fleet.find(f=>f.id===upd.vehiculeId);
      if (veh) upd.montant = String(veh.prix * daysBetween(upd.debut,upd.fin));
    }
    setForm(upd); setErrors(p=>({...p,[k]:null}));
  };

  const selectedVeh = fleet.find(f=>f.id===form.vehiculeId);

  const validate = () => {
    const e = {};
    if (!form.client.trim()) e.client="Requis"; if (!form.phone.trim()) e.phone="Requis";
    if (!form.vehiculeId) e.vehiculeId="Requis"; if (!form.debut) e.debut="Requis";
    if (!form.fin) e.fin="Requis"; if (form.debut&&form.fin&&form.fin<=form.debut) e.fin="Après le début";
    if (!form.montant||isNaN(form.montant)) e.montant="Invalide";
    return e;
  };

  const submit = () => {
    const e=validate(); if(Object.keys(e).length){setErrors(e);return;}
    onSave({id:nextId,client:form.client.trim(),phone:form.phone.trim(),vehicule:selectedVeh?.nom||"",immat:selectedVeh?.immat||"",debut:form.debut,fin:form.fin,statut:form.statut,livraison:{heure:form.lheure,lieu:form.llieu},retour:{heure:form.rheure,lieu:form.rlieu},docs:{permis:false,passeport:false,caution:false},montant:parseInt(form.montant)});
  };

  const inp = (k,type="text",ph="") => (
    <input type={type} value={form[k]} onChange={e=>set(k,e.target.value)} placeholder={ph}
      style={{width:"100%",background:"#0a0a0a",border:`1px solid ${errors[k]?"#ef4444":"#2a2a2a"}`,borderRadius:8,padding:"9px 12px",color:"#e5e5e5",fontSize:13,outline:"none",boxSizing:"border-box"}} />
  );
  const lbl = (text,k) => <label style={{fontSize:11,fontWeight:700,color:errors[k]?"#ef4444":"#555",textTransform:"uppercase",letterSpacing:0.4,display:"block",marginBottom:4}}>{text}{errors[k]&&<span style={{color:"#ef4444",marginLeft:4,fontWeight:400,textTransform:"none"}}>{errors[k]}</span>}</label>;

  return (
    <div style={{position:"fixed",inset:0,background:"#000000dd",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,backdropFilter:"blur(4px)"}}>
      <div style={{background:"#111",border:"1px solid #2a2a2a",borderRadius:14,padding:26,width:580,maxHeight:"90vh",overflowY:"auto",boxShadow:"0 24px 80px #000"}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:20}}>
          <div><div style={{fontSize:10,color:"#e85d04",fontWeight:700,letterSpacing:1}}>NOUVELLE RÉSERVATION</div><div style={{fontSize:20,fontWeight:800,color:"#fff"}}>{nextId}</div></div>
          <button onClick={onClose} style={{background:"none",border:"none",color:"#666",cursor:"pointer",fontSize:20}}>✕</button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 16px"}}>
          <div style={{marginBottom:14}}>{lbl("Nom client","client")}{inp("client","text","Ali Bensouda")}</div>
          <div style={{marginBottom:14}}>{lbl("Téléphone","phone")}{inp("phone","text","+212 6 XX XX XX XX")}</div>
        </div>
        <div style={{marginBottom:14}}>
          {lbl("Véhicule","vehiculeId")}
          <select value={form.vehiculeId} onChange={e=>set("vehiculeId",e.target.value)}
            style={{width:"100%",background:"#0a0a0a",border:`1px solid ${errors.vehiculeId?"#ef4444":"#2a2a2a"}`,borderRadius:8,padding:"9px 12px",color:"#e5e5e5",fontSize:13,outline:"none"}}>
            <option value="">— Sélectionner un véhicule —</option>
            {fleet.filter(f=>f.statut==="libre").map(f=><option key={f.id} value={f.id}>{f.nom} ({f.immat}) · {f.prix} DH/j</option>)}
          </select>
          {selectedVeh&&<div style={{fontSize:11,color:"#e85d04",marginTop:4}}>💰 {selectedVeh.prix} DH/jour</div>}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 16px"}}>
          <div style={{marginBottom:14}}>{lbl("Date début","debut")}{inp("debut","date")}</div>
          <div style={{marginBottom:14}}>{lbl("Date fin","fin")}{inp("fin","date")}</div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 16px"}}>
          <div>
            <div style={{fontSize:11,fontWeight:700,color:"#e85d04",textTransform:"uppercase",letterSpacing:0.4,marginBottom:8}}>🚀 Livraison</div>
            <div style={{display:"grid",gridTemplateColumns:"90px 1fr",gap:"0 8px"}}>
              <div style={{marginBottom:14}}>{lbl("Heure","lheure")}{inp("lheure","time")}</div>
              <div style={{marginBottom:14}}>{lbl("Lieu","llieu")}{inp("llieu","text","Agence")}</div>
            </div>
          </div>
          <div>
            <div style={{fontSize:11,fontWeight:700,color:"#3b82f6",textTransform:"uppercase",letterSpacing:0.4,marginBottom:8}}>🔁 Retour</div>
            <div style={{display:"grid",gridTemplateColumns:"90px 1fr",gap:"0 8px"}}>
              <div style={{marginBottom:14}}>{lbl("Heure","rheure")}{inp("rheure","time")}</div>
              <div style={{marginBottom:14}}>{lbl("Lieu","rlieu")}{inp("rlieu","text","Agence")}</div>
            </div>
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 16px"}}>
          <div style={{marginBottom:14}}>
            {lbl("Montant (DH)","montant")}
            {inp("montant","number","Auto-calculé")}
            {form.debut&&form.fin&&form.fin>form.debut&&selectedVeh&&<div style={{fontSize:11,color:"#22c55e",marginTop:3}}>{daysBetween(form.debut,form.fin)}j × {selectedVeh.prix} DH = {daysBetween(form.debut,form.fin)*selectedVeh.prix} DH</div>}
          </div>
          <div style={{marginBottom:14}}>
            {lbl("Statut","statut")}
            <select value={form.statut} onChange={e=>set("statut",e.target.value)} style={{width:"100%",background:"#0a0a0a",border:"1px solid #2a2a2a",borderRadius:8,padding:"9px 12px",color:"#e5e5e5",fontSize:13,outline:"none"}}>
              {Object.entries(STATUTS).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
        </div>
        <div style={{display:"flex",gap:10,marginTop:4}}>
          <button onClick={submit} style={{flex:1,background:"#e85d04",color:"#fff",border:"none",padding:"12px 0",borderRadius:9,fontSize:14,fontWeight:800,cursor:"pointer"}}>✓ Créer {nextId}</button>
          <button onClick={onClose} style={{background:"#1f1f1f",color:"#888",border:"1px solid #333",padding:"12px 20px",borderRadius:9,fontSize:13,cursor:"pointer"}}>Annuler</button>
        </div>
      </div>
    </div>
  );
}

// ─── VEHICLE FORM ────────────────────────────────────────
const COULEURS = ["#e85d04","#3b82f6","#22c55e","#f59e0b","#8b5cf6","#ec4899","#06b6d4","#ef4444","#a3a3a3","#14b8a6"];
const CATS = ["SUV","Citadine","Berline","Break","Utilitaire","Luxe","4x4"];

function VehicleForm({ vehicle, fleet, onSave, onClose }) {
  const isEdit = !!vehicle;
  const nextId = `V-${String(fleet.length+1).padStart(2,"0")}`;
  const [form, setForm] = useState({
    nom: vehicle?.nom||"", immat: vehicle?.immat||"", cat: vehicle?.cat||"SUV",
    prix: vehicle?.prix||400, km: vehicle?.km||0,
    couleur: vehicle?.couleur||COULEURS[0], statut: vehicle?.statut||"libre",
  });
  const [errors, setErrors] = useState({});

  const set = (k,v) => { setForm(p=>({...p,[k]:v})); setErrors(p=>({...p,[k]:null})); };

  const validate = () => {
    const e = {};
    if (!form.nom.trim()) e.nom = "Requis";
    if (!form.immat.trim()) e.immat = "Requis";
    if (!form.prix || isNaN(form.prix) || form.prix <= 0) e.prix = "Invalide";
    if (form.immat && !isEdit && fleet.find(f=>f.immat.toLowerCase()===form.immat.toLowerCase())) e.immat = "Immat déjà existante";
    return e;
  };

  const submit = () => {
    const e = validate(); if (Object.keys(e).length) { setErrors(e); return; }
    onSave({
      id: vehicle?.id || nextId,
      nom: form.nom.trim(), immat: form.immat.trim().toUpperCase(),
      cat: form.cat, prix: parseInt(form.prix), km: parseInt(form.km)||0,
      couleur: form.couleur, statut: form.statut,
    });
  };

  const inp = (k, type="text", ph="") => (
    <input type={type} value={form[k]} onChange={e=>set(k, e.target.value)} placeholder={ph}
      style={{width:"100%",background:"#0a0a0a",border:`1px solid ${errors[k]?"#ef4444":"#2a2a2a"}`,borderRadius:8,padding:"9px 12px",color:"#e5e5e5",fontSize:13,outline:"none",boxSizing:"border-box"}} />
  );
  const lbl = (text,k) => (
    <label style={{fontSize:11,fontWeight:700,color:errors[k]?"#ef4444":"#555",textTransform:"uppercase",letterSpacing:0.4,display:"block",marginBottom:4}}>
      {text}{errors[k]&&<span style={{color:"#ef4444",marginLeft:4,fontWeight:400,textTransform:"none"}}>— {errors[k]}</span>}
    </label>
  );

  return (
    <div style={{position:"fixed",inset:0,background:"#000000e0",display:"flex",alignItems:"center",justifyContent:"center",zIndex:300,backdropFilter:"blur(4px)"}}>
      <div style={{background:"#111",border:"1px solid #2a2a2a",borderRadius:14,padding:28,width:480,boxShadow:"0 24px 80px #000"}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:22}}>
          <div>
            <div style={{fontSize:10,color:"#e85d04",fontWeight:700,letterSpacing:1}}>{isEdit?"MODIFIER VÉHICULE":"NOUVEAU VÉHICULE"}</div>
            <div style={{fontSize:20,fontWeight:800,color:"#fff",marginTop:2}}>{isEdit?vehicle.nom:nextId}</div>
          </div>
          <button onClick={onClose} style={{background:"none",border:"none",color:"#666",cursor:"pointer",fontSize:20}}>✕</button>
        </div>

        <div style={{marginBottom:14}}>{lbl("Nom du véhicule","nom")}{inp("nom","text","Ex: Dacia Duster 2024")}</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 14px"}}>
          <div style={{marginBottom:14}}>{lbl("Immatriculation","immat")}{inp("immat","text","12345-A-6")}</div>
          <div style={{marginBottom:14}}>
            {lbl("Catégorie","cat")}
            <select value={form.cat} onChange={e=>set("cat",e.target.value)} style={{width:"100%",background:"#0a0a0a",border:"1px solid #2a2a2a",borderRadius:8,padding:"9px 12px",color:"#e5e5e5",fontSize:13,outline:"none"}}>
              {CATS.map(c=><option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div style={{marginBottom:14}}>{lbl("Prix / jour (DH)","prix")}{inp("prix","number","400")}</div>
          <div style={{marginBottom:14}}>{lbl("Kilométrage","km")}{inp("km","number","0")}</div>
        </div>

        <div style={{marginBottom:14}}>
          {lbl("Statut initial","statut")}
          <div style={{display:"flex",gap:8}}>
            {[{k:"libre",l:"Libre",c:"#22c55e"},{k:"maintenance",l:"Maintenance",c:"#ef4444"}].map(s=>(
              <button key={s.k} onClick={()=>set("statut",s.k)}
                style={{flex:1,padding:"8px 0",borderRadius:7,border:`1px solid ${s.c}44`,background:form.statut===s.k?s.c+"22":"transparent",color:form.statut===s.k?s.c:"#555",cursor:"pointer",fontSize:12,fontWeight:700}}>
                {s.l}
              </button>
            ))}
          </div>
        </div>

        <div style={{marginBottom:20}}>
          {lbl("Couleur","couleur")}
          <div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:4}}>
            {COULEURS.map(c=>(
              <button key={c} onClick={()=>set("couleur",c)} style={{width:28,height:28,borderRadius:6,background:c,border:form.couleur===c?"3px solid #fff":"2px solid transparent",cursor:"pointer",outline:"none"}} />
            ))}
          </div>
        </div>

        <div style={{display:"flex",gap:10}}>
          <button onClick={submit} style={{flex:1,background:"#e85d04",color:"#fff",border:"none",padding:"12px 0",borderRadius:9,fontSize:14,fontWeight:800,cursor:"pointer"}}>
            {isEdit?"✓ Enregistrer les modifications":"✓ Ajouter le véhicule"}
          </button>
          <button onClick={onClose} style={{background:"#1f1f1f",color:"#888",border:"1px solid #333",padding:"12px 18px",borderRadius:9,fontSize:13,cursor:"pointer"}}>Annuler</button>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN APP ────────────────────────────────────────────
export default function Auto22() {
  const [reservations, setReservations] = useState(INIT_RES);
  const [fleet, setFleet] = useState(INIT_FLEET);
  const [loaded, setLoaded] = useState(false);
  const [tab, setTab] = useState("reception");
  const [selected, setSelected] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [filterStatut, setFilterStatut] = useState("tous");
  const [search, setSearch] = useState("");
  const [hoveredRow, setHoveredRow] = useState(null);
  const [showVehicleForm, setShowVehicleForm] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [toasts, setToasts] = useState([]);
  const [waHistory, setWaHistory] = useState([]);
  const [waInput, setWaInput] = useState("");
  const [waLoading, setWaLoading] = useState(false);
  const [waPending, setWaPending] = useState(null);
  const [notifPerm, setNotifPerm] = useState("default");
  const [dismissed, setDismissed] = useState([]);

  // ── LOAD from storage on mount ──
  useEffect(() => {
    function loadData() {
      try {
        const resResult = JSON.parse(localStorage.getItem("auto22:reservations") || "null");
        if (resResult) setReservations(resResult);
      } catch {}
      try {
        const fleetResult = JSON.parse(localStorage.getItem("auto22:fleet") || "null");
        if (fleetResult) setFleet(fleetResult);
      } catch {}
      setLoaded(true);
    }
    loadData();
  }, []);

  // ── SAVE reservations to storage ──
  useEffect(() => {
    if (!loaded) return;
    localStorage.setItem("auto22:reservations", JSON.stringify(reservations));
  }, [reservations, loaded]);

  // ── SAVE fleet to storage ──
  useEffect(() => {
    if (!loaded) return;
    localStorage.setItem("auto22:fleet", JSON.stringify(fleet));
  }, [fleet, loaded]);

  useEffect(()=>{ if("Notification" in window) setNotifPerm(Notification.permission); },[]);

  // Auto-update fleet status based on reservations
  useEffect(() => {
    if (!loaded) return;
    setFleet(prev => prev.map(v => {
      if (v.statut === "maintenance") return v;
      const active = reservations.find(r => r.immat === v.immat && ["confirmee","en_cours","attente"].includes(r.statut) && r.debut <= TODAY && r.fin >= TODAY);
      return {...v, statut: active ? "loue" : "libre"};
    }));
  }, [reservations, loaded]);

  const notifications = buildNotifs(reservations).filter(n=>!dismissed.includes(n.id));
  const urgentCount = notifications.filter(n=>n.type==="urgent").length;
  const docsManquants = reservations.filter(r=>getMissing(r.docs).length>0);
  const filtered = reservations.filter(r=>(filterStatut==="tous"||r.statut===filterStatut)&&(!search||[r.client,r.vehicule,r.id].some(s=>s.toLowerCase().includes(search.toLowerCase()))));
  const getRes = id => reservations.find(r=>r.id===id);

  // Loading screen
  if (!loaded) return (
    <div style={{minHeight:"100vh",background:"#0a0a0a",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16}}>
      <div style={{width:44,height:44,background:"#e85d04",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24}}>🚗</div>
      <div style={{fontSize:14,color:"#555",fontWeight:600}}>Chargement AUTO22…</div>
    </div>
  );

  const resetAllData = async () => {
    if (!window.confirm("Supprimer toutes les données u revenir aux données demo ?")) return;
    try { localStorage.removeItem("auto22:reservations"); } catch {}
    try { localStorage.removeItem("auto22:fleet"); } catch {}
    setReservations(INIT_RES); setFleet(INIT_FLEET);
    toast("🔄 Données réinitialisées");
  };

  const toast = (msg,type="success") => { const id=Date.now(); setToasts(p=>[...p,{id,msg,type}]); setTimeout(()=>setToasts(p=>p.filter(t=>t.id!==id)),3500); };

  const toggleDoc = (id,key) => {
    const res = reservations.find(r=>r.id===id);
    setReservations(p=>p.map(r=>r.id===id?{...r,docs:{...r.docs,[key]:!r.docs[key]}}:r));
    setSelected(p=>p?.id===id?{...p,docs:{...p.docs,[key]:!p.docs[key]}}:p);
    if(res) toast(`${DOC_LABELS[key]} ${res.docs[key]?"retiré":"reçu"} — ${res.client}`);
  };
  const updStatut = (id,statut) => { setReservations(p=>p.map(r=>r.id===id?{...r,statut}:r)); setSelected(p=>p?.id===id?{...p,statut}:p); toast(`Statut → ${STATUTS[statut].label}`); };
  const markDoc = (resId,docKey) => {
    const map={permis:"permis",passeport:"passeport",caution:"caution","permis de conduire":"permis","caution / dépôt":"caution"};
    const key=map[docKey?.toLowerCase()]||docKey; if(!key) return;
    setReservations(p=>p.map(r=>r.id===resId?{...r,docs:{...r.docs,[key]:true}}:r));
    const res=getRes(resId); if(res) { toast(`✅ ${DOC_LABELS[key]} reçu — ${res.client}`); if(notifPerm==="granted") new Notification("AUTO22",{body:`${DOC_LABELS[key]} reçu de ${res.client}`}); }
  };
  const saveRes = (nr) => { setReservations(p=>[...p,nr]); setShowForm(false); toast(`✓ ${nr.id} créée — ${nr.client}`); };

  const analyzeWA = async () => {
    if (!waInput.trim()) return; setWaLoading(true);
    const result = await detectDoc(waInput.trim(),reservations);
    const entry={id:Date.now(),raw:waInput.trim(),result,ts:new Date().toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"}),applied:false};
    setWaHistory(p=>[entry,...p]); if(result.confidence!=="low"&&result.reservationId) setWaPending(entry);
    setWaInput(""); setWaLoading(false);
  };
  const applyWA = (entry) => { entry.result.documents?.forEach(d=>markDoc(entry.result.reservationId,d)); setWaHistory(p=>p.map(m=>m.id===entry.id?{...m,applied:true}:m)); setWaPending(null); };

  // CALENDAR DATA
  const daysInMonth = new Date(2026,6,0).getDate(); // 30 days in June
  const calDays = Array.from({length:daysInMonth},(_,i)=>i+1);
  const getResForVehicleDay = (immat,day) => {
    const d = `2026-06-${String(day).padStart(2,"0")}`;
    return reservations.find(r=>r.immat===immat&&r.debut<=d&&r.fin>=d&&r.statut!=="annulee");
  };

  // STATS
  const caByVehicle = fleet.map(v=>({name:v.nom.split(" ").slice(0,2).join(" "),ca:reservations.filter(r=>r.immat===v.immat).reduce((s,r)=>s+r.montant,0),resa:reservations.filter(r=>r.immat===v.immat).length})).filter(v=>v.ca>0);
  const pieData = [{name:"Loués",value:fleet.filter(f=>f.statut==="loue").length,color:"#3b82f6"},{name:"Libres",value:fleet.filter(f=>f.statut==="libre").length,color:"#22c55e"},{name:"Maintenance",value:fleet.filter(f=>f.statut==="maintenance").length,color:"#ef4444"}];

  const $ = {
    app:{minHeight:"100vh",background:"#0a0a0a",color:"#e5e5e5",fontFamily:"'DM Sans','Segoe UI',sans-serif"},
    hdr:{background:"#111",borderBottom:"1px solid #1f1f1f",padding:"0 20px",display:"flex",alignItems:"center",justifyContent:"space-between",height:54,gap:10},
    navBtn:a=>({padding:"5px 11px",borderRadius:6,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:a?"#e85d04":"transparent",color:a?"#fff":"#888",whiteSpace:"nowrap"}),
    stats:{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,padding:"14px 20px"},
    sc:a=>({background:"#111",border:`1px solid ${a}22`,borderRadius:10,padding:"12px 16px",borderLeft:`3px solid ${a}`}),
    content:{padding:"0 20px 24px"},
    table:{width:"100%",borderCollapse:"collapse",background:"#111",borderRadius:10,overflow:"hidden",border:"1px solid #1f1f1f"},
    th:{padding:"10px 14px",textAlign:"left",fontSize:11,fontWeight:700,color:"#555",textTransform:"uppercase",letterSpacing:"0.5px",borderBottom:"1px solid #1f1f1f",background:"#0d0d0d"},
    td:{padding:"11px 14px",fontSize:13,verticalAlign:"middle"},
    badge:(c,b)=>({padding:"3px 10px",borderRadius:5,fontSize:11,fontWeight:700,color:c,background:b,border:`1px solid ${c}44`}),
    section:{background:"#0a0a0a",border:"1px solid #1f1f1f",borderRadius:10,padding:14,marginTop:14},
    modal:{position:"fixed",inset:0,background:"#000000cc",display:"flex",alignItems:"center",justifyContent:"center",zIndex:100,backdropFilter:"blur(4px)"},
    mbox:{background:"#111",border:"1px solid #2a2a2a",borderRadius:14,padding:24,width:560,maxHeight:"90vh",overflowY:"auto",boxShadow:"0 24px 80px #000"},
    dt:ok=>({padding:"6px 14px",borderRadius:6,border:`1px solid ${ok?"#166534":"#7f1d1d"}`,background:ok?"#052e16":"#1a0505",color:ok?"#22c55e":"#ef4444",cursor:"pointer",fontSize:12,fontWeight:700}),
  };

  const TABS = [
    {k:"reception",l:"⚡ WA",badge:docsManquants.length,bc:"#25D366"},
    {k:"reservations",l:"Réservations"},{k:"documents",l:"Documents",badge:docsManquants.length},
    {k:"calendrier",l:"📅 Calendrier"},{k:"flotte",l:"🚗 Flotte"},
    {k:"stats",l:"📊 Stats"},{k:"qrcodes",l:"QR Codes"},{k:"planning",l:"Planning"},
    {k:"notifications",l:"🔔",badge:notifications.length,bc:urgentCount>0?"#ef4444":"#f59e0b"},
  ];

  return (
    <div style={$.app}>
      {/* TOASTS */}
      <div style={{position:"fixed",top:16,right:16,zIndex:999,display:"flex",flexDirection:"column",gap:8,pointerEvents:"none"}}>
        {toasts.map(t=><div key={t.id} style={{background:t.type==="success"?"#052e16":"#1a0505",border:`1px solid ${t.type==="success"?"#22c55e":"#ef4444"}`,borderRadius:9,padding:"10px 16px",fontSize:13,fontWeight:600,color:t.type==="success"?"#22c55e":"#ef4444",boxShadow:"0 8px 24px #000",animation:"slideIn 0.2s ease"}}>{t.msg}</div>)}
      </div>

      {/* HEADER */}
      <header style={$.hdr}>
        <div style={{display:"flex",alignItems:"center",gap:10,minWidth:100}}>
          <div style={{width:30,height:30,background:"#e85d04",borderRadius:6,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15}}>🚗</div>
          <span style={{fontSize:17,fontWeight:800,color:"#fff",letterSpacing:"-0.5px"}}>AUTO22</span>
        </div>
        <nav style={{display:"flex",gap:2,flex:1,justifyContent:"center",flexWrap:"wrap"}}>
          {TABS.map(t=>(
            <button key={t.k} style={$.navBtn(tab===t.k)} onClick={()=>setTab(t.k)}>
              {t.l}{t.badge>0&&<span style={{marginLeft:4,background:t.bc||"#e85d04",color:"#fff",borderRadius:"50%",width:15,height:15,fontSize:9,display:"inline-flex",alignItems:"center",justifyContent:"center"}}>{t.badge}</span>}
            </button>
          ))}
        </nav>
        <div style={{display:"flex",gap:8}}>
          <button onClick={()=>setShowForm(true)} style={{background:"#e85d04",color:"#fff",border:"none",padding:"7px 12px",borderRadius:8,fontSize:12,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap"}}>+ Réservation</button>
          <button onClick={()=>{setEditingVehicle(null);setShowVehicleForm(true);}} style={{background:"#1f1f1f",color:"#aaa",border:"1px solid #333",padding:"7px 12px",borderRadius:8,fontSize:12,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap"}}>🚗 + Véhicule</button>
          <a href={`https://wa.me/${AGENCY_NUMBER}`} target="_blank" rel="noreferrer" style={{background:"#25D366",color:"#fff",padding:"7px 12px",borderRadius:8,fontSize:12,fontWeight:700,textDecoration:"none"}}>💬</a>
          <button onClick={resetAllData} title="Réinitialiser données" style={{background:"#1f1f1f",color:"#555",border:"1px solid #222",padding:"7px 10px",borderRadius:8,fontSize:12,cursor:"pointer"}}>🔄</button>
        </div>
      </header>

      {/* STATS BAR */}
      <div style={$.stats}>
        {[{num:reservations.length,label:"Réservations",accent:"#e85d04"},{num:fleet.filter(f=>f.statut==="loue").length+"/"+fleet.length,label:"Véhicules loués",accent:"#3b82f6"},{num:docsManquants.length,label:"Dossiers incomplets",accent:"#ef4444"},{num:reservations.reduce((s,r)=>s+r.montant,0).toLocaleString("fr-FR")+" DH",label:"CA total",accent:"#22c55e"}].map((st,i)=>(
          <div key={i} style={$.sc(st.accent)}><div style={{fontSize:20,fontWeight:800,color:st.accent,lineHeight:1}}>{st.num}</div><div style={{fontSize:11,color:"#666",marginTop:3}}>{st.label}</div></div>
        ))}
      </div>
      <div style={{padding:"0 20px 10px",display:"flex",alignItems:"center",gap:6}}>
        <div style={{width:6,height:6,borderRadius:"50%",background:"#22c55e"}}></div>
        <span style={{fontSize:11,color:"#444"}}>Données sauvegardées automatiquement dans votre navigateur</span>
      </div>

      <div style={$.content}>

        {/* ── RECEPTION WA ── */}
        {tab==="reception"&&(
          <div>
            <div style={{background:"#0d1a1a",border:"1px solid #134e4a",borderRadius:10,padding:"12px 18px",marginBottom:16,display:"flex",gap:12}}>
              <div style={{fontSize:20}}>⚡</div>
              <div><div style={{fontSize:13,fontWeight:700,color:"#2dd4bf",marginBottom:2}}>Réception automatique · +212 660 499 714</div><div style={{fontSize:12,color:"#5eead4"}}>Client b3at docs → copiez message → Claude identifie → 1 clic ✓</div></div>
            </div>
            <div style={{background:"#111",border:"1px solid #1f1f1f",borderRadius:10,padding:16,marginBottom:14}}>
              <textarea style={{width:"100%",background:"#0a0a0a",border:"1px solid #2a2a2a",borderRadius:8,padding:"10px 14px",color:"#e5e5e5",fontSize:13,resize:"vertical",minHeight:72,outline:"none",boxSizing:"border-box",fontFamily:"inherit"}}
                placeholder='Ex: "R-002 voici mon passeport" ou "Karim Benali, je vous envoie mon permis"'
                value={waInput} onChange={e=>setWaInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&e.ctrlKey&&analyzeWA()} />
              <div style={{display:"flex",justifyContent:"flex-end",marginTop:8}}>
                <button onClick={analyzeWA} disabled={waLoading} style={{background:waLoading?"#1f1f1f":"#e85d04",color:"#fff",border:"none",padding:"9px 22px",borderRadius:8,fontSize:13,fontWeight:700,cursor:waLoading?"default":"pointer"}}>{waLoading?"⏳ Analyse…":"🔍 Analyser avec Claude"}</button>
              </div>
            </div>
            {waPending&&!waPending.applied&&(
              <div style={{background:"#052e16",border:"2px solid #22c55e",borderRadius:10,padding:14,marginBottom:14}}>
                <div style={{fontSize:12,color:"#22c55e",fontWeight:700,marginBottom:8}}>✅ Document identifié</div>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
                  <div>
                    <div style={{fontWeight:700,color:"#fff",fontSize:14}}>{getRes(waPending.result.reservationId)?.client} <span style={{color:"#e85d04",fontFamily:"monospace",fontSize:12}}>{waPending.result.reservationId}</span></div>
                    <div style={{fontSize:13,color:"#86efac"}}>{waPending.result.documents?.map(d=>DOC_LABELS[d]||d).join(", ")}</div>
                    <div style={{fontSize:11,color:"#4ade80"}}>{waPending.result.message}</div>
                  </div>
                  <div style={{display:"flex",gap:8}}>
                    <button onClick={()=>applyWA(waPending)} style={{background:"#22c55e",color:"#fff",border:"none",padding:"9px 20px",borderRadius:8,fontSize:13,fontWeight:800,cursor:"pointer"}}>✓ Marquer reçu</button>
                    <button onClick={()=>setWaPending(null)} style={{background:"#0a0a0a",color:"#888",border:"1px solid #333",padding:"9px 14px",borderRadius:8,fontSize:12,cursor:"pointer"}}>Ignorer</button>
                  </div>
                </div>
              </div>
            )}
            {waHistory.map(m=>(
              <div key={m.id} style={{background:"#111",border:`1px solid ${m.applied?"#166534":"#1f1f1f"}`,borderRadius:10,padding:"11px 14px",marginBottom:7,display:"flex",gap:10,alignItems:"center"}}>
                <div style={{fontSize:10,color:"#555",minWidth:36}}>{m.ts}</div>
                <div style={{flex:1}}>
                  <div style={{fontSize:12,color:"#555",fontStyle:"italic",marginBottom:3}}>"{m.raw}"</div>
                  {m.result.reservationId?<div style={{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
                    <span style={{fontFamily:"monospace",fontSize:12,color:"#e85d04",fontWeight:700}}>{m.result.reservationId}</span>
                    <span style={{fontSize:12,color:"#fff"}}>{getRes(m.result.reservationId)?.client}</span>
                    <span style={{fontSize:12,color:"#aaa"}}>→</span>
                    <span style={{fontSize:12,fontWeight:600}}>{m.result.documents?.map(d=>DOC_LABELS[d]||d).join(", ")}</span>
                  </div>:<div style={{fontSize:12,color:"#ef4444"}}>⚠ {m.result.message}</div>}
                </div>
                {m.applied?<span style={{fontSize:11,color:"#22c55e",fontWeight:700}}>✓</span>:m.result.reservationId&&<button onClick={()=>applyWA(m)} style={{background:"#1f1f1f",border:"1px solid #333",color:"#aaa",padding:"5px 10px",borderRadius:6,fontSize:11,cursor:"pointer"}}>Marquer</button>}
              </div>
            ))}
          </div>
        )}

        {/* ── RESERVATIONS ── */}
        {tab==="reservations"&&(
          <>
            <div style={{display:"flex",gap:10,marginBottom:14}}>
              <input style={{background:"#161616",border:"1px solid #2a2a2a",borderRadius:8,padding:"8px 14px",color:"#e5e5e5",fontSize:13,outline:"none",flex:1}} placeholder="🔍  Rechercher…" value={search} onChange={e=>setSearch(e.target.value)} />
              <select style={{background:"#161616",border:"1px solid #2a2a2a",borderRadius:8,padding:"8px 14px",color:"#e5e5e5",fontSize:13,outline:"none"}} value={filterStatut} onChange={e=>setFilterStatut(e.target.value)}>
                <option value="tous">Tous les statuts</option>
                {Object.entries(STATUTS).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
            <table style={$.table}>
              <thead><tr>{["Réf","Client","Véhicule","Période","Docs","Statut","Montant","Actions"].map(h=><th key={h} style={$.th}>{h}</th>)}</tr></thead>
              <tbody>{filtered.map(r=>{const st=STATUTS[r.statut];const miss=getMissing(r.docs).length;return(
                <tr key={r.id} style={{borderBottom:"1px solid #161616",cursor:"pointer",background:hoveredRow===r.id?"#161616":"transparent"}} onMouseEnter={()=>setHoveredRow(r.id)} onMouseLeave={()=>setHoveredRow(null)} onClick={()=>setSelected(r)}>
                  <td style={$.td}><span style={{color:"#e85d04",fontWeight:700,fontFamily:"monospace"}}>{r.id}</span></td>
                  <td style={$.td}><div style={{fontWeight:600,color:"#fff"}}>{r.client}</div><div style={{fontSize:11,color:"#666"}}>{r.phone}</div></td>
                  <td style={$.td}><div style={{fontSize:12}}>{r.vehicule}</div><div style={{fontSize:11,color:"#555",fontFamily:"monospace"}}>{r.immat}</div></td>
                  <td style={$.td}><div style={{fontSize:12}}>{r.debut} → {r.fin}</div><div style={{fontSize:11,color:"#666"}}>{daysBetween(r.debut,r.fin)}j</div></td>
                  <td style={$.td}>{miss===0?<span style={{color:"#22c55e",fontSize:12,fontWeight:600}}>✓</span>:<span style={{color:"#ef4444",fontSize:12,fontWeight:700}}>⚠{miss}</span>}</td>
                  <td style={$.td}><span style={$.badge(st.color,st.bg)}>{st.label}</span></td>
                  <td style={{...$.td,fontWeight:700}}>{r.montant.toLocaleString("fr-FR")} DH</td>
                  <td style={$.td} onClick={e=>e.stopPropagation()}>
                    <div style={{display:"flex",gap:5}}>
                      <button onClick={()=>exportDossier(r)} style={{background:"#1f1f1f",border:"1px solid #333",color:"#aaa",padding:"4px 8px",borderRadius:5,fontSize:10,cursor:"pointer"}}>📄</button>
                      <button onClick={()=>generateContract(r)} style={{background:"#1f1f1f",border:"1px solid #333",color:"#f59e0b",padding:"4px 8px",borderRadius:5,fontSize:10,cursor:"pointer"}}>📝</button>
                      <a href={buildReminderUrl(r)} target="_blank" rel="noreferrer" style={{background:"#1f1f1f",border:"1px solid #333",color:"#25D366",padding:"4px 8px",borderRadius:5,fontSize:10,textDecoration:"none"}}>💬</a>
                    </div>
                  </td>
                </tr>
              );})}</tbody>
            </table>
          </>
        )}

        {/* ── DOCUMENTS ── */}
        {tab==="documents"&&(
          <table style={$.table}>
            <thead><tr>{["Client","Véhicule","Permis","Passeport","Caution","Dossier","PDF"].map(h=><th key={h} style={$.th}>{h}</th>)}</tr></thead>
            <tbody>{reservations.map(r=>(
              <tr key={r.id} style={{borderBottom:"1px solid #161616"}}>
                <td style={$.td}><div style={{fontWeight:600,color:"#fff"}}>{r.client}</div><div style={{fontSize:11,color:"#666"}}>{r.id}</div></td>
                <td style={{...$.td,fontSize:12,color:"#aaa"}}>{r.vehicule}</td>
                {["permis","passeport","caution"].map(doc=><td key={doc} style={$.td}><button style={$.dt(r.docs[doc])} onClick={()=>toggleDoc(r.id,doc)}>{r.docs[doc]?"✓ Reçu":"✗ Manquant"}</button></td>)}
                <td style={$.td}>{getMissing(r.docs).length===0?<span style={{color:"#22c55e",fontSize:12}}>✓</span>:<span style={{color:"#ef4444",fontSize:12,fontWeight:700}}>⚠{getMissing(r.docs).length}</span>}</td>
                <td style={$.td}><div style={{display:"flex",gap:5}}><button onClick={()=>exportDossier(r)} style={{background:"#1f1f1f",border:"1px solid #333",color:"#aaa",padding:"5px 10px",borderRadius:6,fontSize:11,cursor:"pointer"}}>📄 Dossier</button><button onClick={()=>generateContract(r)} style={{background:"#1f1f1f",border:"1px solid #f59e0b44",color:"#f59e0b",padding:"5px 10px",borderRadius:6,fontSize:11,cursor:"pointer"}}>📝 Contrat</button></div></td>
              </tr>
            ))}</tbody>
          </table>
        )}

        {/* ── CALENDRIER GANTT ── */}
        {tab==="calendrier"&&(
          <div>
            <div style={{fontSize:14,fontWeight:700,color:"#fff",marginBottom:14}}>Juin 2026 — Vue Gantt par véhicule</div>
            <div style={{overflowX:"auto"}}>
              <table style={{width:"100%",borderCollapse:"collapse",background:"#111",borderRadius:10,border:"1px solid #1f1f1f",minWidth:800}}>
                <thead>
                  <tr>
                    <th style={{...$.th,minWidth:160,position:"sticky",left:0,background:"#0d0d0d",zIndex:2}}>Véhicule</th>
                    {calDays.map(d=>(
                      <th key={d} style={{...$.th,width:28,padding:"8px 2px",textAlign:"center",fontSize:10,background:d===parseInt(TODAY.split("-")[2])?"#e85d0422":"#0d0d0d",color:d===parseInt(TODAY.split("-")[2])?"#e85d04":"#555"}}>
                        {d}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {fleet.map(v=>(
                    <tr key={v.id} style={{borderBottom:"1px solid #161616"}}>
                      <td style={{...$.td,position:"sticky",left:0,background:"#111",zIndex:1,minWidth:160}}>
                        <div style={{display:"flex",alignItems:"center",gap:8}}>
                          <div style={{width:8,height:8,borderRadius:"50%",background:v.couleur,flexShrink:0}}></div>
                          <div>
                            <div style={{fontSize:11,fontWeight:600,color:"#e5e5e5"}}>{v.nom.split(" ").slice(0,2).join(" ")}</div>
                            <div style={{fontSize:10,color:"#555",fontFamily:"monospace"}}>{v.immat}</div>
                          </div>
                        </div>
                      </td>
                      {calDays.map(d=>{
                        const res=getResForVehicleDay(v.immat,d);
                        const isToday=d===parseInt(TODAY.split("-")[2]);
                        const st=res?STATUTS[res.statut]:null;
                        return(
                          <td key={d} style={{padding:"2px",textAlign:"center",background:isToday?"#1a0e00":"transparent",cursor:res?"pointer":"default"}} onClick={()=>res&&setSelected(res)}>
                            {res?(
                              <div style={{width:"100%",height:20,borderRadius:3,background:st?.color+"33",border:`1px solid ${st?.color}66`,display:"flex",alignItems:"center",justifyContent:"center"}} title={`${res.id} - ${res.client}`}>
                                <div style={{width:6,height:6,borderRadius:"50%",background:st?.color}}></div>
                              </div>
                            ):v.statut==="maintenance"?(
                              <div style={{width:"100%",height:20,borderRadius:3,background:"#ef444422",display:"flex",alignItems:"center",justifyContent:"center"}}>
                                <span style={{fontSize:8}}>🔧</span>
                              </div>
                            ):null}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={{display:"flex",gap:16,marginTop:12,flexWrap:"wrap"}}>
              {Object.entries(STATUTS).map(([k,v])=><div key={k} style={{display:"flex",alignItems:"center",gap:5,fontSize:11,color:"#888"}}><div style={{width:12,height:12,borderRadius:3,background:v.color+"44",border:`1px solid ${v.color}88`}}></div>{v.label}</div>)}
              <div style={{display:"flex",alignItems:"center",gap:5,fontSize:11,color:"#888"}}><span>🔧</span>Maintenance</div>
            </div>
          </div>
        )}

        {/* ── FLOTTE ── */}
        {tab==="flotte"&&(
          <div>
            {/* Toolbar */}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
              <div style={{fontSize:13,color:"#666"}}>{fleet.length} véhicule{fleet.length>1?"s":""} · {fleet.filter(f=>f.statut==="libre").length} libre{fleet.filter(f=>f.statut==="libre").length!==1?"s":""} · {fleet.filter(f=>f.statut==="loue").length} en location</div>
              <button onClick={()=>{setEditingVehicle(null);setShowVehicleForm(true);}} style={{background:"#e85d04",color:"#fff",border:"none",padding:"9px 18px",borderRadius:8,fontSize:13,fontWeight:700,cursor:"pointer",display:"flex",alignItems:"center",gap:6}}>
                ➕ Ajouter un véhicule
              </button>
            </div>

            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:14}}>
              {fleet.map(v=>{
                const currentRes=reservations.find(r=>r.immat===v.immat&&!["annulee","terminee"].includes(r.statut)&&r.debut<=TODAY&&r.fin>=TODAY);
                const totalCA=reservations.filter(r=>r.immat===v.immat).reduce((s,r)=>s+r.montant,0);
                const SC={libre:{color:"#22c55e",bg:"#052e16",label:"Libre"},loue:{color:"#3b82f6",bg:"#0c1a3a",label:"En location"},maintenance:{color:"#ef4444",bg:"#1a0505",label:"Maintenance"}};
                const sc=SC[v.statut];
                const isDeleting=confirmDelete===v.id;
                return(
                  <div key={v.id} style={{background:"#111",border:`1px solid ${isDeleting?"#ef4444":v.couleur+"33"}`,borderRadius:12,padding:18,borderLeft:`3px solid ${v.couleur}`,transition:"border-color 0.2s"}}>
                    {/* Header */}
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{fontSize:14,fontWeight:700,color:"#fff",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{v.nom}</div>
                        <div style={{fontSize:11,color:"#555",fontFamily:"monospace"}}>{v.immat} · {v.cat}</div>
                      </div>
                      <div style={{display:"flex",gap:6,alignItems:"center",marginLeft:8,flexShrink:0}}>
                        <span style={{padding:"3px 9px",borderRadius:5,fontSize:11,fontWeight:700,color:sc.color,background:sc.bg,border:`1px solid ${sc.color}44`}}>{sc.label}</span>
                        <button onClick={()=>{setEditingVehicle(v);setShowVehicleForm(true);}} title="Modifier" style={{background:"#1f1f1f",border:"1px solid #333",color:"#f59e0b",borderRadius:6,width:28,height:28,cursor:"pointer",fontSize:13,display:"flex",alignItems:"center",justifyContent:"center"}}>✏️</button>
                        <button onClick={()=>setConfirmDelete(isDeleting?null:v.id)} title="Supprimer" style={{background:isDeleting?"#3d0000":"#1f1f1f",border:`1px solid ${isDeleting?"#ef4444":"#333"}`,color:isDeleting?"#ef4444":"#666",borderRadius:6,width:28,height:28,cursor:"pointer",fontSize:13,display:"flex",alignItems:"center",justifyContent:"center"}}>🗑️</button>
                      </div>
                    </div>

                    {/* Confirm delete */}
                    {isDeleting&&(
                      <div style={{background:"#1a0505",border:"1px solid #ef4444",borderRadius:8,padding:"10px 12px",marginBottom:10}}>
                        <div style={{fontSize:12,color:"#ef4444",fontWeight:700,marginBottom:8}}>Supprimer {v.nom} ?</div>
                        <div style={{display:"flex",gap:8}}>
                          <button onClick={()=>deleteVehicle(v.id)} style={{flex:1,background:"#ef4444",color:"#fff",border:"none",padding:"7px 0",borderRadius:7,fontSize:12,fontWeight:700,cursor:"pointer"}}>Oui, supprimer</button>
                          <button onClick={()=>setConfirmDelete(null)} style={{flex:1,background:"#1f1f1f",color:"#888",border:"1px solid #333",padding:"7px 0",borderRadius:7,fontSize:12,cursor:"pointer"}}>Annuler</button>
                        </div>
                      </div>
                    )}

                    {/* Prix & km */}
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                      <div>
                        <div style={{fontSize:11,color:"#666"}}>Prix / jour</div>
                        <div style={{display:"flex",alignItems:"center",gap:5}}>
                          <input type="number" value={v.prix} onChange={e=>setFleet(p=>p.map(f=>f.id===v.id?{...f,prix:parseInt(e.target.value)||0}:f))}
                            style={{width:72,background:"#0a0a0a",border:"1px solid #2a2a2a",borderRadius:6,padding:"4px 8px",color:"#e85d04",fontSize:14,fontWeight:700,outline:"none"}} />
                          <span style={{fontSize:12,color:"#666"}}>DH</span>
                        </div>
                      </div>
                      <div style={{textAlign:"center"}}>
                        <div style={{fontSize:11,color:"#666"}}>Kilométrage</div>
                        <div style={{fontSize:13,fontWeight:700,color:"#e5e5e5"}}>{v.km.toLocaleString("fr-FR")} km</div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontSize:11,color:"#666"}}>CA total</div>
                        <div style={{fontSize:13,fontWeight:700,color:"#22c55e"}}>{totalCA.toLocaleString("fr-FR")} DH</div>
                      </div>
                    </div>

                    {/* Current reservation */}
                    {currentRes&&(
                      <div style={{background:"#0c1a3a",border:"1px solid #3b82f644",borderRadius:8,padding:"8px 12px",fontSize:12,marginBottom:10}}>
                        <div style={{color:"#3b82f6",fontWeight:700}}>En location</div>
                        <div style={{color:"#aaa"}}>{currentRes.client} · jusqu'au {currentRes.fin}</div>
                      </div>
                    )}

                    {/* Status buttons */}
                    <div style={{display:"flex",gap:5}}>
                      {Object.entries(SC).map(([s,c])=>(
                        <button key={s} onClick={()=>setFleet(p=>p.map(f=>f.id===v.id?{...f,statut:s}:f))}
                          style={{flex:1,padding:"5px 0",borderRadius:6,border:`1px solid ${c.color}44`,background:v.statut===s?c.bg:"transparent",color:v.statut===s?c.color:"#555",cursor:"pointer",fontSize:10,fontWeight:600}}>
                          {c.label}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}

              {/* Add card */}
              <div onClick={()=>{setEditingVehicle(null);setShowVehicleForm(true);}}
                style={{background:"#0a0a0a",border:"2px dashed #2a2a2a",borderRadius:12,padding:18,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:10,cursor:"pointer",minHeight:160,transition:"border-color 0.2s"}}
                onMouseEnter={e=>e.currentTarget.style.borderColor="#e85d04"}
                onMouseLeave={e=>e.currentTarget.style.borderColor="#2a2a2a"}>
                <div style={{fontSize:32,color:"#333"}}>＋</div>
                <div style={{fontSize:13,color:"#555",fontWeight:600}}>Ajouter un véhicule</div>
              </div>
            </div>
          </div>
        )}

        {/* ── STATS ── */}
        {tab==="stats"&&(
          <div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20,marginBottom:20}}>
              <div style={{background:"#111",border:"1px solid #1f1f1f",borderRadius:12,padding:20}}>
                <div style={{fontSize:12,fontWeight:700,color:"#555",textTransform:"uppercase",letterSpacing:0.5,marginBottom:16}}>Chiffre d'affaires mensuel (DH)</div>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={STATS_HISTORY}>
                    <XAxis dataKey="mois" tick={{fill:"#666",fontSize:11}} axisLine={false} tickLine={false} />
                    <YAxis tick={{fill:"#666",fontSize:10}} axisLine={false} tickLine={false} tickFormatter={v=>`${(v/1000).toFixed(0)}k`} />
                    <Tooltip contentStyle={{background:"#1f1f1f",border:"1px solid #333",borderRadius:8,color:"#e5e5e5"}} formatter={v=>[v.toLocaleString("fr-FR")+" DH","CA"]} />
                    <Bar dataKey="ca" fill="#e85d04" radius={[4,4,0,0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div style={{background:"#111",border:"1px solid #1f1f1f",borderRadius:12,padding:20}}>
                <div style={{fontSize:12,fontWeight:700,color:"#555",textTransform:"uppercase",letterSpacing:0.5,marginBottom:16}}>État de la flotte</div>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" outerRadius={70} dataKey="value" label={({name,value})=>`${name}: ${value}`} labelLine={false}>
                      {pieData.map((e,i)=><Cell key={i} fill={e.color} />)}
                    </Pie>
                    <Tooltip contentStyle={{background:"#1f1f1f",border:"1px solid #333",borderRadius:8,color:"#e5e5e5"}} />
                    <Legend formatter={v=><span style={{color:"#aaa",fontSize:12}}>{v}</span>} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div style={{background:"#111",border:"1px solid #1f1f1f",borderRadius:12,padding:20,marginBottom:20}}>
              <div style={{fontSize:12,fontWeight:700,color:"#555",textTransform:"uppercase",letterSpacing:0.5,marginBottom:16}}>CA par véhicule</div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={caByVehicle} layout="vertical">
                  <XAxis type="number" tick={{fill:"#666",fontSize:10}} axisLine={false} tickLine={false} tickFormatter={v=>`${(v/1000).toFixed(0)}k`} />
                  <YAxis type="category" dataKey="name" tick={{fill:"#aaa",fontSize:11}} axisLine={false} tickLine={false} width={120} />
                  <Tooltip contentStyle={{background:"#1f1f1f",border:"1px solid #333",borderRadius:8,color:"#e5e5e5"}} formatter={v=>[v.toLocaleString("fr-FR")+" DH","CA"]} />
                  <Bar dataKey="ca" fill="#3b82f6" radius={[0,4,4,0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
              {[
                {label:"Véhicule le + loué",val:caByVehicle.sort((a,b)=>b.resa-a.resa)[0]?.name||"-",accent:"#e85d04"},
                {label:"Taux d'occupation",val:Math.round((fleet.filter(f=>f.statut==="loue").length/fleet.length)*100)+"%",accent:"#3b82f6"},
                {label:"Réservations ce mois",val:STATS_HISTORY[5].res,accent:"#22c55e"},
                {label:"Panier moyen",val:Math.round(reservations.reduce((s,r)=>s+r.montant,0)/reservations.length).toLocaleString("fr-FR")+" DH",accent:"#f59e0b"},
              ].map((k,i)=>(
                <div key={i} style={$.sc(k.accent)}><div style={{fontSize:18,fontWeight:800,color:k.accent}}>{k.val}</div><div style={{fontSize:11,color:"#666",marginTop:3}}>{k.label}</div></div>
              ))}
            </div>
          </div>
        )}

        {/* ── QR CODES ── */}
        {tab==="qrcodes"&&(
          <>
            <div style={{background:"#0d1a0d",border:"1px solid #166534",borderRadius:10,padding:"12px 18px",marginBottom:16,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div style={{fontSize:13,fontWeight:700,color:"#22c55e"}}>✅ QR connecté · +212 660 499 714 · Message pré-rempli par client</div>
              <button onClick={()=>window.print()} style={{background:"#1f1f1f",border:"1px solid #333",color:"#aaa",padding:"7px 14px",borderRadius:8,cursor:"pointer",fontSize:12,fontWeight:600}}>🖨️ Imprimer</button>
            </div>
            <div className="qr-cards" style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(210px,1fr))",gap:16}}>
              {reservations.map(r=>{const waUrl=buildWAUrl(r);const miss=getMissing(r.docs);return(
                <div key={r.id}>
                  <div style={{background:"#fff",borderRadius:12,overflow:"hidden",border:"1px solid #e5e7eb",fontFamily:"'DM Sans',sans-serif",boxShadow:"0 4px 16px rgba(0,0,0,0.1)"}}>
                    <div style={{background:"#e85d04",padding:"9px 13px",display:"flex",justifyContent:"space-between"}}>
                      <div style={{fontSize:14,fontWeight:800,color:"#fff"}}>AUTO22</div>
                      <div style={{background:"rgba(255,255,255,0.2)",borderRadius:4,padding:"2px 8px",fontSize:11,fontWeight:700,color:"#fff"}}>{r.id}</div>
                    </div>
                    <div style={{padding:"9px 13px 6px",borderBottom:"1px solid #f3f4f6"}}>
                      <div style={{fontSize:12,fontWeight:700,color:"#111"}}>{r.client}</div>
                      <div style={{fontSize:10,color:"#666"}}>{r.vehicule}</div>
                    </div>
                    <div style={{padding:"10px 13px",background:"#fafafa",display:"flex",justifyContent:"center"}}>
                      <img src={buildQRUrl(waUrl,120)} alt="QR" width={120} height={120} style={{borderRadius:5,border:"1px solid #eee"}} onError={e=>e.target.style.display="none"} />
                    </div>
                    <div style={{padding:"8px 13px 10px"}}>
                      <div style={{fontSize:9,fontWeight:700,color:"#e85d04",marginBottom:4,textTransform:"uppercase"}}>📸 Scannez & envoyez docs</div>
                      {miss.length>0?miss.map(d=><div key={d} style={{fontSize:9,color:"#dc2626"}}>❌ {d}</div>):<div style={{fontSize:9,color:"#16a34a"}}>✅ Dossier complet</div>}
                    </div>
                  </div>
                  <div style={{display:"flex",gap:6,marginTop:7}}>
                    <a href={waUrl} target="_blank" rel="noreferrer" style={{flex:1,background:"#25D366",color:"#fff",padding:"7px 0",borderRadius:7,fontSize:11,fontWeight:700,textDecoration:"none",textAlign:"center"}}>💬 WA</a>
                    <button onClick={()=>exportDossier(r)} style={{flex:1,background:"#1f1f1f",border:"1px solid #333",color:"#aaa",padding:"7px 0",borderRadius:7,fontSize:11,fontWeight:700,cursor:"pointer"}}>📄 PDF</button>
                    <button onClick={()=>generateContract(r)} style={{flex:1,background:"#1f1f1f",border:"1px solid #f59e0b44",color:"#f59e0b",padding:"7px 0",borderRadius:7,fontSize:11,fontWeight:700,cursor:"pointer"}}>📝</button>
                  </div>
                </div>
              );})}
            </div>
          </>
        )}

        {/* ── PLANNING ── */}
        {tab==="planning"&&(
          <div style={{display:"flex",flexDirection:"column",gap:7}}>
            {reservations.sort((a,b)=>a.debut.localeCompare(b.debut)).map(r=>{
              const st=STATUTS[r.statut]; const miss=getMissing(r.docs).length; const dStart=daysBetween(TODAY,r.debut);
              return(
                <div key={r.id} style={{background:"#111",border:"1px solid #1f1f1f",borderRadius:10,padding:"11px 16px",display:"flex",alignItems:"center",gap:12,cursor:"pointer"}} onClick={()=>setSelected(r)}>
                  <span style={{color:"#e85d04",fontFamily:"monospace",fontSize:12,fontWeight:700,minWidth:48}}>{r.id}</span>
                  <span style={{fontWeight:600,minWidth:130,color:"#fff",fontSize:13}}>{r.client}</span>
                  <span style={{fontSize:12,color:"#888",flex:1}}>{r.vehicule}</span>
                  <span style={{fontSize:12,color:"#aaa"}}>🚀 {r.debut} → 🔁 {r.fin}</span>
                  {miss>0&&<span style={{fontSize:11,color:"#ef4444",fontWeight:700}}>⚠{miss}</span>}
                  <span style={$.badge(st.color,st.bg)}>{st.label}</span>
                  <div style={{display:"flex",gap:5}} onClick={e=>e.stopPropagation()}>
                    <a href={buildReminderUrl(r)} target="_blank" rel="noreferrer" title="Envoyer rappel WA" style={{background:"#0d1a0d",border:"1px solid #25D36644",color:"#25D366",padding:"5px 9px",borderRadius:6,fontSize:11,textDecoration:"none"}}>📱 Rappel</a>
                    <button onClick={()=>generateContract(r)} style={{background:"#1f1f1f",border:"1px solid #f59e0b44",color:"#f59e0b",padding:"5px 9px",borderRadius:6,fontSize:11,cursor:"pointer"}}>📝</button>
                    <button onClick={()=>exportDossier(r)} style={{background:"#1f1f1f",border:"1px solid #333",color:"#aaa",padding:"5px 9px",borderRadius:6,fontSize:11,cursor:"pointer"}}>📄</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ── NOTIFICATIONS ── */}
        {tab==="notifications"&&(
          <div>
            {notifPerm!=="granted"&&<div style={{background:"#1c1003",border:"1px solid #92400e",borderRadius:10,padding:"14px 18px",marginBottom:16,display:"flex",justifyContent:"space-between",alignItems:"center"}}><div><div style={{fontSize:13,fontWeight:700,color:"#f59e0b"}}>Activer notifications navigateur</div><div style={{fontSize:12,color:"#d97706"}}>Alertes même quand l'onglet est en arrière-plan</div></div><button onClick={async()=>{const p=await Notification.requestPermission();setNotifPerm(p);if(p==="granted")toast("🔔 Notifications activées !");}} style={{background:"#f59e0b",color:"#111",border:"none",padding:"8px 16px",borderRadius:8,fontSize:12,fontWeight:700,cursor:"pointer"}}>🔔 Activer</button></div>}
            {notifications.length===0?<div style={{textAlign:"center",padding:"60px 0",color:"#444"}}><div style={{fontSize:40,marginBottom:12}}>✅</div><div style={{fontSize:16,fontWeight:700,color:"#555"}}>Tout est en ordre</div><div style={{fontSize:13,color:"#444",marginTop:4}}>Aucune alerte</div></div>:notifications.map(n=>{
              const c={urgent:{bg:"#1a0505",border:"#ef4444",text:"#ef4444"},warning:{bg:"#1c1003",border:"#f59e0b",text:"#f59e0b"},info:{bg:"#0c1a3a",border:"#3b82f6",text:"#3b82f6"}}[n.type];
              return(<div key={n.id} style={{background:c.bg,border:`1px solid ${c.border}`,borderRadius:10,padding:"13px 16px",marginBottom:9,display:"flex",alignItems:"center",gap:14}}>
                <div style={{fontSize:22}}>{n.icon}</div>
                <div style={{flex:1}}><div style={{fontSize:13,fontWeight:700,color:c.text}}>{n.title}</div><div style={{fontSize:13,color:"#e5e5e5"}}>{n.body}</div><div style={{fontSize:11,color:"#666"}}>{n.sub}</div></div>
                <div style={{display:"flex",gap:8}}>
                  {n.resId&&<button onClick={()=>{setSelected(reservations.find(r=>r.id===n.resId));setTab("reservations");}} style={{background:"#1f1f1f",border:"1px solid #333",color:"#aaa",padding:"6px 12px",borderRadius:7,fontSize:11,cursor:"pointer"}}>Voir</button>}
                  <button onClick={()=>setDismissed(p=>[...p,n.id])} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:16}}>✕</button>
                </div>
              </div>);
            })}
          </div>
        )}
      </div>

      {/* MODAL */}
      {selected&&(
        <div style={$.modal} onClick={()=>setSelected(null)}>
          <div style={$.mbox} onClick={e=>e.stopPropagation()}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16}}>
              <div><div style={{fontSize:10,color:"#e85d04",fontWeight:700,letterSpacing:1}}>{selected.id}</div><div style={{fontSize:20,fontWeight:800,color:"#fff"}}>{selected.client}</div><div style={{fontSize:12,color:"#666"}}>{selected.phone}</div></div>
              <div style={{display:"flex",gap:7}}>
                <button onClick={()=>generateContract(selected)} style={{background:"#1f1f1f",border:"1px solid #f59e0b44",color:"#f59e0b",padding:"6px 12px",borderRadius:7,fontSize:12,cursor:"pointer",fontWeight:600}}>📝 Contrat</button>
                <button onClick={()=>exportDossier(selected)} style={{background:"#1f1f1f",border:"1px solid #333",color:"#aaa",padding:"6px 12px",borderRadius:7,fontSize:12,cursor:"pointer",fontWeight:600}}>📄 Dossier</button>
                <button style={{background:"none",border:"none",color:"#666",cursor:"pointer",fontSize:20}} onClick={()=>setSelected(null)}>✕</button>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr auto",gap:16}}>
              <div>
                <div style={$.section}><div style={{fontSize:10,color:"#555",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5,marginBottom:8}}>Véhicule</div><div style={{fontWeight:600,color:"#fff"}}>{selected.vehicule} <span style={{fontFamily:"monospace",fontSize:10,color:"#555"}}>{selected.immat}</span></div><div style={{fontWeight:800,color:"#e85d04",fontSize:16,marginTop:4}}>{selected.montant.toLocaleString("fr-FR")} DH · {daysBetween(selected.debut,selected.fin)}j</div></div>
                <div style={$.section}><div style={{fontSize:10,color:"#555",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5,marginBottom:10}}>Documents</div><div style={{display:"flex",gap:8,flexWrap:"wrap"}}>{["permis","passeport","caution"].map(doc=><button key={doc} style={$.dt(selected.docs[doc])} onClick={()=>toggleDoc(selected.id,doc)}>{selected.docs[doc]?"✓":"✗"} {DOC_LABELS[doc].split(" ")[0]}</button>)}</div></div>
                <div style={$.section}><div style={{fontSize:10,color:"#555",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5,marginBottom:10}}>Statut</div><div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{Object.entries(STATUTS).map(([k,v])=><button key={k} onClick={()=>updStatut(selected.id,k)} style={{padding:"5px 12px",borderRadius:6,border:`1px solid ${v.color}44`,background:selected.statut===k?v.bg:"transparent",color:selected.statut===k?v.color:"#555",cursor:"pointer",fontSize:12,fontWeight:700}}>{v.label}</button>)}</div></div>
                <div style={{...$.section,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div style={{fontSize:12,color:"#fff",fontWeight:600}}>{selected.phone}</div>
                  <div style={{display:"flex",gap:8}}>
                    <a href={buildWAUrl(selected)} target="_blank" rel="noreferrer" style={{background:"#25D366",color:"#fff",padding:"8px 14px",borderRadius:8,fontSize:12,fontWeight:700,textDecoration:"none"}}>💬 WA Docs</a>
                    <a href={buildReminderUrl(selected)} target="_blank" rel="noreferrer" style={{background:"#0d1a0d",border:"1px solid #25D36644",color:"#25D366",padding:"8px 14px",borderRadius:8,fontSize:12,fontWeight:700,textDecoration:"none"}}>📱 Rappel</a>
                  </div>
                </div>
              </div>
              <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:10}}>
                <div style={{fontSize:10,color:"#25D366",fontWeight:700,textTransform:"uppercase"}}>QR Client</div>
                <div style={{background:"#fff",padding:7,borderRadius:10,border:"2px solid #25D366"}}>
                  <img src={buildQRUrl(buildWAUrl(selected),120)} alt="QR" width={120} height={120} style={{display:"block",borderRadius:4}} />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {showForm&&<ReservationForm reservations={reservations} fleet={fleet} onSave={saveRes} onClose={()=>setShowForm(false)} />}
      {showVehicleForm&&<VehicleForm vehicle={editingVehicle} fleet={fleet} onSave={v=>{if(editingVehicle){setFleet(p=>p.map(f=>f.id===v.id?v:f));toast(`✓ ${v.nom} modifié`);}else{setFleet(p=>[...p,v]);toast(`✓ ${v.nom} ajouté`);}setShowVehicleForm(false);setEditingVehicle(null);}} onClose={()=>{setShowVehicleForm(false);setEditingVehicle(null);}} />}

      <style>{`
        @keyframes slideIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
        @media print{body{background:white!important}header,nav,[data-noprint]{display:none!important}.qr-cards{display:grid!important;grid-template-columns:repeat(3,210px)!important;gap:14px!important;padding:20px!important}}
      `}</style>
    </div>
  );
}
