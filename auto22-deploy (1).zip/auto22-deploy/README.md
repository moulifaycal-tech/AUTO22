# AUTO22 — Système de Gestion Location

## Fichiers du projet
```
auto22/
├── index.html
├── package.json
├── vite.config.js
├── .gitignore
├── public/
│   └── manifest.json
└── src/
    ├── main.jsx
    └── App.jsx
```

## Déploiement sur Vercel (gratuit)

### Étape 1 — Upload sur GitHub
1. Ouvre github.com → "New repository" → nom: `auto22`
2. Upload tous ces fichiers (drag & drop)
3. Commit

### Étape 2 — Déploiement Vercel
1. Va sur vercel.com → "Sign up with GitHub"
2. "New Project" → sélectionne ton repo `auto22`
3. Framework: **Vite** (auto-détecté)
4. Clique "Deploy"
5. ✅ Ton URL: `auto22-xxx.vercel.app`

### Étape 3 — App mobile (PWA)
1. Ouvre l'URL sur ton portable
2. Safari/Chrome → "Ajouter à l'écran d'accueil"
3. Icon AUTO22 apparaît comme une vraie app 🚗
